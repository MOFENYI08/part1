/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.icetask1;

import java.util.Scanner;

/**
 *
 * @author letha
 */
public class Icetask1 {

    public static void main(String[] args) {
        

public class PasswordGenerator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your full name: ");
        String fullName = scanner.nextLine().trim();

        // Convert name to lowercase
        String lowerName = fullName.toLowerCase();

        // Split into first and last name
        String[] parts = lowerName.split("\\s+");
        String firstName = parts[0];
        String lastName = parts[1];

        // make the first letter of first name an uppercase
        String firstLetterUpper = firstName.substring(0, 1).toUpperCase();

        // Extract last three characters of last name
        String lastThree = lastName.substring(lastName.length() - 3);

        // Replace all 'a' with '@' in the full name (lowercase version)
        String modifiedName = lowerName.replace('a', '@');

        // Count total characters excluding spaces
        int charCount = fullName.replaceAll("\\s+", "").length();

        // remove space from modified name to match expected output
        String secretCode = firstLetterUpper + lastThree + modifiedName.replaceAll("\\s+", "") + charCount;

        System.out.println("Secret Code: " + secretCode);

        scanner.close();
    }
}